<?php
    session_start();
?>

<h4>Remove Cart</h4>

<?php
    $_SESSION["cart"] = [];

?>